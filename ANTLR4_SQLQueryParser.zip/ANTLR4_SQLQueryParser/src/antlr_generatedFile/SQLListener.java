// Generated from SQL.g4 by ANTLR 4.13.0
package antlr_generatedFile;
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link SQLParser}.
 */
public interface SQLListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link SQLParser#identifier}.
	 * @param ctx the parse tree
	 */
	void enterIdentifier(SQLParser.IdentifierContext ctx);
	/**
	 * Exit a parse tree produced by {@link SQLParser#identifier}.
	 * @param ctx the parse tree
	 */
	void exitIdentifier(SQLParser.IdentifierContext ctx);
	/**
	 * Enter a parse tree produced by {@link SQLParser#string}.
	 * @param ctx the parse tree
	 */
	void enterString(SQLParser.StringContext ctx);
	/**
	 * Exit a parse tree produced by {@link SQLParser#string}.
	 * @param ctx the parse tree
	 */
	void exitString(SQLParser.StringContext ctx);
	/**
	 * Enter a parse tree produced by {@link SQLParser#dateLiteral}.
	 * @param ctx the parse tree
	 */
	void enterDateLiteral(SQLParser.DateLiteralContext ctx);
	/**
	 * Exit a parse tree produced by {@link SQLParser#dateLiteral}.
	 * @param ctx the parse tree
	 */
	void exitDateLiteral(SQLParser.DateLiteralContext ctx);
	/**
	 * Enter a parse tree produced by {@link SQLParser#startRule}.
	 * @param ctx the parse tree
	 */
	void enterStartRule(SQLParser.StartRuleContext ctx);
	/**
	 * Exit a parse tree produced by {@link SQLParser#startRule}.
	 * @param ctx the parse tree
	 */
	void exitStartRule(SQLParser.StartRuleContext ctx);
	/**
	 * Enter a parse tree produced by {@link SQLParser#selectStatement}.
	 * @param ctx the parse tree
	 */
	void enterSelectStatement(SQLParser.SelectStatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link SQLParser#selectStatement}.
	 * @param ctx the parse tree
	 */
	void exitSelectStatement(SQLParser.SelectStatementContext ctx);
	/**
	 * Enter a parse tree produced by {@link SQLParser#topClause}.
	 * @param ctx the parse tree
	 */
	void enterTopClause(SQLParser.TopClauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link SQLParser#topClause}.
	 * @param ctx the parse tree
	 */
	void exitTopClause(SQLParser.TopClauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link SQLParser#selectItems}.
	 * @param ctx the parse tree
	 */
	void enterSelectItems(SQLParser.SelectItemsContext ctx);
	/**
	 * Exit a parse tree produced by {@link SQLParser#selectItems}.
	 * @param ctx the parse tree
	 */
	void exitSelectItems(SQLParser.SelectItemsContext ctx);
	/**
	 * Enter a parse tree produced by {@link SQLParser#selectItem}.
	 * @param ctx the parse tree
	 */
	void enterSelectItem(SQLParser.SelectItemContext ctx);
	/**
	 * Exit a parse tree produced by {@link SQLParser#selectItem}.
	 * @param ctx the parse tree
	 */
	void exitSelectItem(SQLParser.SelectItemContext ctx);
	/**
	 * Enter a parse tree produced by {@link SQLParser#fromItemAlias}.
	 * @param ctx the parse tree
	 */
	void enterFromItemAlias(SQLParser.FromItemAliasContext ctx);
	/**
	 * Exit a parse tree produced by {@link SQLParser#fromItemAlias}.
	 * @param ctx the parse tree
	 */
	void exitFromItemAlias(SQLParser.FromItemAliasContext ctx);
	/**
	 * Enter a parse tree produced by {@link SQLParser#fromItem}.
	 * @param ctx the parse tree
	 */
	void enterFromItem(SQLParser.FromItemContext ctx);
	/**
	 * Exit a parse tree produced by {@link SQLParser#fromItem}.
	 * @param ctx the parse tree
	 */
	void exitFromItem(SQLParser.FromItemContext ctx);
	/**
	 * Enter a parse tree produced by {@link SQLParser#joinClause}.
	 * @param ctx the parse tree
	 */
	void enterJoinClause(SQLParser.JoinClauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link SQLParser#joinClause}.
	 * @param ctx the parse tree
	 */
	void exitJoinClause(SQLParser.JoinClauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link SQLParser#joinType}.
	 * @param ctx the parse tree
	 */
	void enterJoinType(SQLParser.JoinTypeContext ctx);
	/**
	 * Exit a parse tree produced by {@link SQLParser#joinType}.
	 * @param ctx the parse tree
	 */
	void exitJoinType(SQLParser.JoinTypeContext ctx);
	/**
	 * Enter a parse tree produced by {@link SQLParser#condition}.
	 * @param ctx the parse tree
	 */
	void enterCondition(SQLParser.ConditionContext ctx);
	/**
	 * Exit a parse tree produced by {@link SQLParser#condition}.
	 * @param ctx the parse tree
	 */
	void exitCondition(SQLParser.ConditionContext ctx);
	/**
	 * Enter a parse tree produced by {@link SQLParser#binaryExpression}.
	 * @param ctx the parse tree
	 */
	void enterBinaryExpression(SQLParser.BinaryExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link SQLParser#binaryExpression}.
	 * @param ctx the parse tree
	 */
	void exitBinaryExpression(SQLParser.BinaryExpressionContext ctx);
	/**
	 * Enter a parse tree produced by {@link SQLParser#nestedQuery}.
	 * @param ctx the parse tree
	 */
	void enterNestedQuery(SQLParser.NestedQueryContext ctx);
	/**
	 * Exit a parse tree produced by {@link SQLParser#nestedQuery}.
	 * @param ctx the parse tree
	 */
	void exitNestedQuery(SQLParser.NestedQueryContext ctx);
	/**
	 * Enter a parse tree produced by {@link SQLParser#expression}.
	 * @param ctx the parse tree
	 */
	void enterExpression(SQLParser.ExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link SQLParser#expression}.
	 * @param ctx the parse tree
	 */
	void exitExpression(SQLParser.ExpressionContext ctx);
	/**
	 * Enter a parse tree produced by {@link SQLParser#function}.
	 * @param ctx the parse tree
	 */
	void enterFunction(SQLParser.FunctionContext ctx);
	/**
	 * Exit a parse tree produced by {@link SQLParser#function}.
	 * @param ctx the parse tree
	 */
	void exitFunction(SQLParser.FunctionContext ctx);
	/**
	 * Enter a parse tree produced by {@link SQLParser#expressionList}.
	 * @param ctx the parse tree
	 */
	void enterExpressionList(SQLParser.ExpressionListContext ctx);
	/**
	 * Exit a parse tree produced by {@link SQLParser#expressionList}.
	 * @param ctx the parse tree
	 */
	void exitExpressionList(SQLParser.ExpressionListContext ctx);
	/**
	 * Enter a parse tree produced by {@link SQLParser#caseExpression}.
	 * @param ctx the parse tree
	 */
	void enterCaseExpression(SQLParser.CaseExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link SQLParser#caseExpression}.
	 * @param ctx the parse tree
	 */
	void exitCaseExpression(SQLParser.CaseExpressionContext ctx);
	/**
	 * Enter a parse tree produced by {@link SQLParser#whenClause}.
	 * @param ctx the parse tree
	 */
	void enterWhenClause(SQLParser.WhenClauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link SQLParser#whenClause}.
	 * @param ctx the parse tree
	 */
	void exitWhenClause(SQLParser.WhenClauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link SQLParser#comparisonOperator}.
	 * @param ctx the parse tree
	 */
	void enterComparisonOperator(SQLParser.ComparisonOperatorContext ctx);
	/**
	 * Exit a parse tree produced by {@link SQLParser#comparisonOperator}.
	 * @param ctx the parse tree
	 */
	void exitComparisonOperator(SQLParser.ComparisonOperatorContext ctx);
	/**
	 * Enter a parse tree produced by {@link SQLParser#whereClause}.
	 * @param ctx the parse tree
	 */
	void enterWhereClause(SQLParser.WhereClauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link SQLParser#whereClause}.
	 * @param ctx the parse tree
	 */
	void exitWhereClause(SQLParser.WhereClauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link SQLParser#orderByClause}.
	 * @param ctx the parse tree
	 */
	void enterOrderByClause(SQLParser.OrderByClauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link SQLParser#orderByClause}.
	 * @param ctx the parse tree
	 */
	void exitOrderByClause(SQLParser.OrderByClauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link SQLParser#orderItem}.
	 * @param ctx the parse tree
	 */
	void enterOrderItem(SQLParser.OrderItemContext ctx);
	/**
	 * Exit a parse tree produced by {@link SQLParser#orderItem}.
	 * @param ctx the parse tree
	 */
	void exitOrderItem(SQLParser.OrderItemContext ctx);
	/**
	 * Enter a parse tree produced by {@link SQLParser#limitClause}.
	 * @param ctx the parse tree
	 */
	void enterLimitClause(SQLParser.LimitClauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link SQLParser#limitClause}.
	 * @param ctx the parse tree
	 */
	void exitLimitClause(SQLParser.LimitClauseContext ctx);
}