package controller;

import java.util.Scanner;

import org.antlr.v4.runtime.CharStreams;
import org.antlr.v4.runtime.CharStream;
import org.antlr.v4.runtime.CommonTokenStream;
import org.json.JSONObject;

import antlr_generatedFile.SQLLexer;
import antlr_generatedFile.SQLParser;

public class Main {

	// this method is for to make the query in a single String variable.
	public static String queryTaker() {
		Scanner scanner = new Scanner(System.in);

		System.out.println("Enter the SQL query (terminate with 'END' on a new line):");
		StringBuilder input = new StringBuilder();
		String line;

		while (scanner.hasNextLine()) {
			line = scanner.nextLine();
			if (line.equals("END")) {
				break;
			}
			input.append(line);
			input.append(" ");
			// input.append(System.lineSeparator());
		}
		String query = input.toString();

		// Remove line breaks and extra spaces from the query
		query = query.replaceAll("\\s+", " ");

//"\\s+": This is a regular expression pattern that matches one or more whitespace characters.
// The \\s represents a whitespace character, and the + indicates that there can be one or more occurrences of the preceding pattern.
// " ": This is the replacement value that replaces all occurrences of the matched pattern. In this case, it is a single space character.

		// Store the query in a String variable
		String convertedQuery = query;

		System.out.println("Whole query: ");
		System.out.println(convertedQuery);
		scanner.close();
		return convertedQuery;
	}

	public static void main(String[] args) {

		// String query = null;
		// query = new String(Files.readAllBytes(Paths.get(args[0])));
		// if (args.length != 1) {
		// System.out.println("kindly provide the Sql input file appropriately");
		// return;
		// }
		try {

			String query = queryTaker();
			if (!query.contains("SELECT")) {
				System.err.println("Invalid SQL query: doesn't even contain SELECT keyword.");
				return;
			}
			
			
			if(query.contains(";")) {
				int semecolonIndex = query.lastIndexOf(";");
				query = query.substring(0, semecolonIndex);
			}

			CharStream inputStream = CharStreams.fromString(query);
			SQLLexer lexer = new SQLLexer(inputStream);
			CommonTokenStream tokenStream = new CommonTokenStream(lexer);
			SQLParser parser = new SQLParser(tokenStream);

			MyCustomListener myListener = new MyCustomListener();
			parser.addParseListener(myListener);

			// Start the parsing process
			parser.startRule();

			// Get the JSON representation of the parsed SQL query from the listener
			JSONObject jsonResult = myListener.getJsonResult();
			System.out.println(jsonResult.toString(4));

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}