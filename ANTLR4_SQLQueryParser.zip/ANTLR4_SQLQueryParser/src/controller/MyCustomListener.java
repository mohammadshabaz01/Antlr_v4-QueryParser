package controller;

import org.json.JSONArray;
import org.json.JSONObject;

import antlr_generatedFile.SQLBaseListener;
import antlr_generatedFile.SQLParser;

public class MyCustomListener extends SQLBaseListener {
    // Member Variables
    private JSONObject jsonResult;            // For storing the final JSON representation of the SQL query.
    private JSONArray selectItemsArray;       // For storing information about selected items.
    private JSONArray joinArray;              // For storing information about joins.
    private boolean insideNestedQuery;        // Flag to track if inside a nested query.

    // Constructor
    public MyCustomListener() {
        // Initialize member variables
        jsonResult = new JSONObject();        // Initialize the main JSON object.
        selectItemsArray = new JSONArray();   // Initialize the array for SELECT items.
        joinArray = new JSONArray();          // Initialize the array for JOIN clauses.
        insideNestedQuery = false;            // Set the flag to false initially.
    }


	    @Override
	    public void enterNestedQuery(SQLParser.NestedQueryContext ctx) {
	        insideNestedQuery = true;
	    }

	    @Override
	    public void exitNestedQuery(SQLParser.NestedQueryContext ctx) {
	        insideNestedQuery = false;
	    }
	    
	    @Override
	    public void exitSelectItem(SQLParser.SelectItemContext ctx) {
	        // Get the full text of the selected item
	        String fullColumn = ctx.getText();
	        String columnName;
	        String alias = null;
	        JSONObject selectObject = new JSONObject();

	        if (fullColumn.equals("*")) {
	            // If the selected item is "*", it represents selecting all columns.
	            selectItemsArray.put("*");
	        } else {
	            // If it's not "*", process the selected item.
	            if (!insideNestedQuery) {
	                // Check if we are not inside a nested query (using the insideNestedQuery flag).
	                if (fullColumn.contains("AS")) {
	                    // If the selected item contains "AS," it has an alias.
	                    int lastIndex = fullColumn.lastIndexOf("AS");
	                    columnName = fullColumn.substring(0, lastIndex);
	                    alias = fullColumn.substring(lastIndex + 2).trim(); // Trim to remove leading/trailing spaces

	                    // Check if the alias is enclosed in double quotes and remove them if present.
	                    if (alias.startsWith("\"") && alias.endsWith("\"")) {
	                        alias = alias.substring(1, alias.length() - 1);
	                    }

	                    // Construct a JSON object with the column name and alias.
	                    selectObject.put("Column_Name", columnName);
	                    selectObject.put("Column_Alias", alias);

	                    // Add the select object to the selectItemsArray.
	                    selectItemsArray.put(selectObject);
	                } else {
	                    // If there's no "AS," add the fullColumn directly to the selectItemsArray.
	                    selectItemsArray.put(fullColumn);
	                }
	            }
	        }
	    }

	    
	    @Override
	    public void exitTopClause(SQLParser.TopClauseContext ctx) {
	        int topValue = Integer.parseInt(ctx.DIGIT().getText());
	        jsonResult.put("TOP", topValue);
	    }

    @Override
    public void exitSelectItems(SQLParser.SelectItemsContext ctx) {
        jsonResult.put("SELECT", selectItemsArray);
    }

    
    @Override
    public void exitFromItemAlias(SQLParser.FromItemAliasContext ctx) {
        // Get the table name from the parse context
        String tablename = ctx.fromItem().identifier().getText();

        // Check if we are within a join clause
        if (ctx.getParent() instanceof SQLParser.JoinClauseContext) {
            // We are within a join clause, so don't update the "FROM" clause
        } else {
            // We are in the "FROM" clause, so update the "FROM" object
            JSONObject fromObject = new JSONObject();
            fromObject.put("TABLE_NAME", tablename);

            if (ctx.identifier() != null) {
                // If there's an alias, extract it
                String alias1 = ctx.identifier().getText();
                fromObject.put("Table_Aliases", alias1);

                // Check if the alias is enclosed in double quotes and remove them if present
                if (alias1.startsWith("\"") && alias1.endsWith("\"")) {
                    alias1 = alias1.substring(1, alias1.length() - 1);
                    fromObject.put("Table_Aliases", alias1);
                }
            }

            // Add the "FROM" object to the JSON result
            jsonResult.put("FROM", fromObject);
        }
    }


  
    @Override
    public void exitJoinClause(SQLParser.JoinClauseContext ctx) {
        // Extract join type, from item, and join condition from the parse context
        String joinTypeText = ctx.joinType() != null ? ctx.joinType().getText().toLowerCase() : "join"; // Convert to lowercase for easier comparison
        String fromItem = ctx.fromItemAlias().fromItem().identifier().getText();
        String onCondition = ctx.condition().getText();

        // Map recognized join types to standard SQL join types
        String mappedJoinType;
        if (joinTypeText.contains("inner") || joinTypeText.contains("join")) {
            mappedJoinType = "INNER JOIN";
        } else if (joinTypeText.contains("left outer") || joinTypeText.contains("left")) {
            mappedJoinType = "LEFT JOIN";
        } else if (joinTypeText.contains("right outer") || joinTypeText.contains("right")) {
            mappedJoinType = "RIGHT JOIN";
        } else if (joinTypeText.contains("outer") || joinTypeText.contains("full outer") || joinTypeText.contains("full")) {
            mappedJoinType = "FULL JOIN";
        } else {
            mappedJoinType = joinTypeText; // Use the original join type if not recognized
        }

        // Create a JSON object to represent the join clause and its details
        JSONObject joinObject = new JSONObject();
        JSONObject tableForJoin = new JSONObject();

        if (ctx.fromItemAlias().identifier() != null) {
            // If there's an alias for the from item, extract it
            String alias = ctx.fromItemAlias().identifier().getText();
            tableForJoin.put("Table_Name", fromItem);
            tableForJoin.put("Table_Aliases", alias);
            joinObject.put("From Table", tableForJoin);
        } else {
            // If there's no alias, use the from item as is
            String fromtable = ctx.fromItemAlias().fromItem().getText();
            joinObject.put("From Table", fromtable);
        }

        // Add join type, join condition, and the from item (in JSON) to the joinObject
        joinObject.put("Join Type", mappedJoinType);
        joinObject.put("On Condition", onCondition);

        // Add the current join object to the JSON array of joins
        joinArray.put(joinObject);

        // Update the JSON result under the "JOIN" key with the joinArray
        jsonResult.put("JOIN", joinArray);
    }


   
    

    @Override
    public void exitWhereClause(SQLParser.WhereClauseContext ctx) {
        // Get the text of the WHERE condition
        String whereCondition = ctx.binaryExpression().getText();
        
        // Add the WHERE condition to the JSON result
        jsonResult.put("WHERE", whereCondition);
    }


    @Override
    public void exitOrderByClause(SQLParser.OrderByClauseContext ctx) {
    	JSONArray orderArray = new JSONArray();
        for (SQLParser.OrderItemContext orderItemContext : ctx.orderItem()) {
            String orderItem = orderItemContext.identifier().getText();
            JSONObject orderObject = new JSONObject();
            orderObject.put("Column", orderItem);
            if (orderItemContext.DESC() != null) {
                orderObject.put("Sort Order", "DESC");
            } else {
                orderObject.put("Sort Order", "ASC");
            }
            orderArray.put(orderObject);
        }
        jsonResult.put("ORDER BY", orderArray);
    }

    @Override
    public void exitLimitClause(SQLParser.LimitClauseContext ctx) {
        int limitValue = Integer.parseInt(ctx.DIGIT().getText());
        jsonResult.put("LIMIT", limitValue);
    }

    public JSONObject getJsonResult() {
        return jsonResult;
    }
}   